var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0g2.yrs._.js")
R.c("server/chunks/0prs_next_dist_esm_build_templates_app-route_0_l72r2.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_095lj93.js")
R.m(78254)
module.exports=R.m(78254).exports
