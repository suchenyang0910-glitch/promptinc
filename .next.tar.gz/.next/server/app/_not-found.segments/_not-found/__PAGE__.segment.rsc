1:"$Sreact.fragment"
2:I[70096,["/_next/static/chunks/0zgfiedjtpgpd.js","/_next/static/chunks/0a~jlh-njdd1e.js","/_next/static/chunks/02_ckw-2jdvpg.js"],""]
3:I[78602,["/_next/static/chunks/0zgfiedjtpgpd.js","/_next/static/chunks/0a~jlh-njdd1e.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","main",null,{"className":"min-h-screen bg-slate-950 text-white flex items-center justify-center p-6","children":["$","div",null,{"className":"text-center space-y-6","children":[["$","h1",null,{"className":"text-5xl font-bold","children":"Game Not Found"}],["$","p",null,{"className":"text-slate-400","children":"This game does not exist or has been moved."}],["$","$L2",null,{"href":"/games","className":"inline-block bg-blue-600 hover:bg-blue-500 px-6 py-3 rounded-xl font-bold","children":"Browse Games"}]]}]}],[["$","script","script-0",{"src":"/_next/static/chunks/02_ckw-2jdvpg.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"T8y4xlsWKQEsgLuCs3Ijq"}
5:null
