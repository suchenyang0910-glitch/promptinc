1:"$Sreact.fragment"
3:I[78602,["/_next/static/chunks/0zgfiedjtpgpd.js","/_next/static/chunks/0a~jlh-njdd1e.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"T8y4xlsWKQEsgLuCs3Ijq"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/games/promptinc;307;"}
