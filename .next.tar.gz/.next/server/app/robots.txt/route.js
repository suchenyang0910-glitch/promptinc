var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__0z-7bd.._.js")
R.c("server/chunks/[root-of-the-server]__0g2.yrs._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_0o-41u5.js")
R.m(30202)
module.exports=R.m(30202).exports
