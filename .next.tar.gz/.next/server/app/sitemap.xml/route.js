var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0f7u-4o._.js")
R.c("server/chunks/[root-of-the-server]__0g2.yrs._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_036gxb_.js")
R.m(69768)
module.exports=R.m(69768).exports
