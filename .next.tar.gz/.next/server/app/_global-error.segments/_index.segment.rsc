1:"$Sreact.fragment"
2:I[79456,["/_next/static/chunks/0zgfiedjtpgpd.js","/_next/static/chunks/0a~jlh-njdd1e.js"],"default"]
3:I[11532,["/_next/static/chunks/0zgfiedjtpgpd.js","/_next/static/chunks/0a~jlh-njdd1e.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"T8y4xlsWKQEsgLuCs3Ijq"}
