globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/T8y4xlsWKQEsgLuCs3Ijq/_buildManifest.js",
    "static/T8y4xlsWKQEsgLuCs3Ijq/_ssgManifest.js",
    "static/T8y4xlsWKQEsgLuCs3Ijq/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0qwz6fb47~l7k.js",
    "static/chunks/0pcu~p6n9yl6..js",
    "static/chunks/0s3cb7pqw3cow.js",
    "static/chunks/0rirafyi6bdqb.js",
    "static/chunks/turbopack-0whorbj4hot2~.js"
  ]
};
